const http = require('http');
const fs = require('fs');

function startHtmlServer() {
  const hostname = '0.0.0.0';
  const port = 8080;

const server = http.createServer(function(request, response) {
    if (request.url === '/style.css') {
      response.writeHead(200, { 'Content-Type': 'text/css' });
      const css = fs.readFileSync('./style.css', 'utf8');
      response.write(css);
      response.end();
    } else {
      response.writeHead(200, { 'Content-Type': 'text/html' });
      const html = fs.readFileSync('./index.html', 'utf8');
      response.write(html);
      response.end();
    }
  });
  server.listen(port, hostname, () => {
    console.log("Server running at http://web-x0e2e8b75-7c79.docode.fi.qwasar.io");
  });
}

startHtmlServer();